﻿namespace SLAUSolver
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.matrixTextBox = new System.Windows.Forms.TextBox();
            this.vectorTextBox = new System.Windows.Forms.TextBox();
            this.initialGuessTextBox = new System.Windows.Forms.TextBox();
            this.toleranceTextBox = new System.Windows.Forms.TextBox();
            this.maxIterationsTextBox = new System.Windows.Forms.TextBox();
            this.solveButton = new System.Windows.Forms.Button();
            this.resultTextBox = new System.Windows.Forms.RichTextBox();
            this.zedGraphControl = new ZedGraph.ZedGraphControl();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.example1Button = new System.Windows.Forms.Button();
            this.example2Button = new System.Windows.Forms.Button();
            this.example3Button = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // matrixTextBox
            // 
            this.matrixTextBox.Location = new System.Drawing.Point(12, 27);
            this.matrixTextBox.Multiline = true;
            this.matrixTextBox.Name = "matrixTextBox";
            this.matrixTextBox.Size = new System.Drawing.Size(250, 80);
            this.matrixTextBox.TabIndex = 0;
            this.matrixTextBox.Text = "4 1 1\r\n1 6 1\r\n1 1 8";
            // 
            // vectorTextBox
            // 
            this.vectorTextBox.Location = new System.Drawing.Point(12, 132);
            this.vectorTextBox.Name = "vectorTextBox";
            this.vectorTextBox.Size = new System.Drawing.Size(250, 20);
            this.vectorTextBox.TabIndex = 1;
            this.vectorTextBox.Text = "1 2 3";
            // 
            // initialGuessTextBox
            // 
            this.initialGuessTextBox.Location = new System.Drawing.Point(12, 181);
            this.initialGuessTextBox.Name = "initialGuessTextBox";
            this.initialGuessTextBox.Size = new System.Drawing.Size(250, 20);
            this.initialGuessTextBox.TabIndex = 2;
            this.initialGuessTextBox.Text = "0";
            // 
            // toleranceTextBox
            // 
            this.toleranceTextBox.Location = new System.Drawing.Point(12, 230);
            this.toleranceTextBox.Name = "toleranceTextBox";
            this.toleranceTextBox.Size = new System.Drawing.Size(100, 20);
            this.toleranceTextBox.TabIndex = 3;
            this.toleranceTextBox.Text = "0.0001";
            // 
            // maxIterationsTextBox
            // 
            this.maxIterationsTextBox.Location = new System.Drawing.Point(12, 279);
            this.maxIterationsTextBox.Name = "maxIterationsTextBox";
            this.maxIterationsTextBox.Size = new System.Drawing.Size(100, 20);
            this.maxIterationsTextBox.TabIndex = 4;
            this.maxIterationsTextBox.Text = "100";
            // 
            // solveButton
            // 
            this.solveButton.Location = new System.Drawing.Point(12, 315);
            this.solveButton.Name = "solveButton";
            this.solveButton.Size = new System.Drawing.Size(100, 30);
            this.solveButton.TabIndex = 5;
            this.solveButton.Text = "Решить";
            this.solveButton.UseVisualStyleBackColor = true;
            this.solveButton.Click += new System.EventHandler(this.solveButton_Click);
            // 
            // resultTextBox
            // 
            this.resultTextBox.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.resultTextBox.Location = new System.Drawing.Point(12, 360);
            this.resultTextBox.Name = "resultTextBox";
            this.resultTextBox.ReadOnly = true;
            this.resultTextBox.Size = new System.Drawing.Size(250, 200);
            this.resultTextBox.TabIndex = 6;
            this.resultTextBox.Text = "";
            // 
            // zedGraphControl
            // 
            this.zedGraphControl.Location = new System.Drawing.Point(280, 12);
            this.zedGraphControl.Name = "zedGraphControl";
            this.zedGraphControl.ScrollGrace = 0D;
            this.zedGraphControl.ScrollMaxX = 0D;
            this.zedGraphControl.ScrollMaxY = 0D;
            this.zedGraphControl.ScrollMaxY2 = 0D;
            this.zedGraphControl.ScrollMinX = 0D;
            this.zedGraphControl.ScrollMinY = 0D;
            this.zedGraphControl.ScrollMinY2 = 0D;
            this.zedGraphControl.Size = new System.Drawing.Size(600, 550);
            this.zedGraphControl.TabIndex = 7;
            this.zedGraphControl.UseExtendedPrintDialog = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Матрица A (3x3 пример):";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Вектор b:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 165);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Начальное приближение:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 214);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Точность:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 263);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Макс. итераций:";
            // 
            // example1Button
            // 
            this.example1Button.Location = new System.Drawing.Point(169, 230);
            this.example1Button.Name = "example1Button";
            this.example1Button.Size = new System.Drawing.Size(70, 30);
            this.example1Button.TabIndex = 13;
            this.example1Button.Text = "Пример 1";
            this.example1Button.UseVisualStyleBackColor = true;
            this.example1Button.Click += new System.EventHandler(this.example1Button_Click);
            // 
            // example2Button
            // 
            this.example2Button.Location = new System.Drawing.Point(169, 273);
            this.example2Button.Name = "example2Button";
            this.example2Button.Size = new System.Drawing.Size(70, 30);
            this.example2Button.TabIndex = 14;
            this.example2Button.Text = "Пример 2";
            this.example2Button.UseVisualStyleBackColor = true;
            this.example2Button.Click += new System.EventHandler(this.example2Button_Click);
            // 
            // example3Button
            // 
            this.example3Button.Location = new System.Drawing.Point(169, 315);
            this.example3Button.Name = "example3Button";
            this.example3Button.Size = new System.Drawing.Size(70, 30);
            this.example3Button.TabIndex = 15;
            this.example3Button.Text = "Пример 3";
            this.example3Button.UseVisualStyleBackColor = true;
            this.example3Button.Click += new System.EventHandler(this.example3Button_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(166, 214);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Примеры:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 580);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.example3Button);
            this.Controls.Add(this.example2Button);
            this.Controls.Add(this.example1Button);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.zedGraphControl);
            this.Controls.Add(this.resultTextBox);
            this.Controls.Add(this.solveButton);
            this.Controls.Add(this.maxIterationsTextBox);
            this.Controls.Add(this.toleranceTextBox);
            this.Controls.Add(this.initialGuessTextBox);
            this.Controls.Add(this.vectorTextBox);
            this.Controls.Add(this.matrixTextBox);
            this.Name = "Form1";
            this.Text = "Решение СЛАУ - Методы Якоби и Зейделя";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox matrixTextBox;
        private System.Windows.Forms.TextBox vectorTextBox;
        private System.Windows.Forms.TextBox initialGuessTextBox;
        private System.Windows.Forms.TextBox toleranceTextBox;
        private System.Windows.Forms.TextBox maxIterationsTextBox;
        private System.Windows.Forms.Button solveButton;
        private System.Windows.Forms.RichTextBox resultTextBox;
        private ZedGraph.ZedGraphControl zedGraphControl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button example1Button;
        private System.Windows.Forms.Button example2Button;
        private System.Windows.Forms.Button example3Button;
        private System.Windows.Forms.Label label6;
    }
}