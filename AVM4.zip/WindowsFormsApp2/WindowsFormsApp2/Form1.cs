﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using ZedGraph;

namespace SLAUSolver
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void solveButton_Click(object sender, EventArgs e)
        {
            try
            {
                double[,] A = ParseMatrix(matrixTextBox.Text);
                double[] b = ParseVector(vectorTextBox.Text);
                double initialGuessValue = double.Parse(initialGuessTextBox.Text);
                double tolerance = double.Parse(toleranceTextBox.Text);
                int maxIterations = int.Parse(maxIterationsTextBox.Text);

                // Создаем начальное приближение на основе одного числа
                double[] x0 = CreateInitialGuess(A.GetLength(0), initialGuessValue);

                var jacobiResult = SolveJacobi(A, b, x0, tolerance, maxIterations);
                var seidelResult = SolveSeidel(A, b, x0, tolerance, maxIterations);

                DisplayResults(jacobiResult, seidelResult);
                PlotResiduals(jacobiResult, seidelResult);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void example1Button_Click(object sender, EventArgs e)
        {
            // Пример 1: Хорошо обусловленная матрица (быстрая сходимость)
            matrixTextBox.Text = "4 1 1\r\n1 6 1\r\n1 1 8";
            vectorTextBox.Text = "1 2 3";
            initialGuessTextBox.Text = "0";
            toleranceTextBox.Text = "0.0001";
            maxIterationsTextBox.Text = "100";
        }

        private void example2Button_Click(object sender, EventArgs e)
        {
            // Пример 2: Матрица с диагональным преобладанием (умеренная сходимость)
            matrixTextBox.Text = "3 1 0\r\n1 4 1\r\n0 1 5";
            vectorTextBox.Text = "4 6 6";
            initialGuessTextBox.Text = "0";
            toleranceTextBox.Text = "0.0001";
            maxIterationsTextBox.Text = "100";
        }

        private void example3Button_Click(object sender, EventArgs e)
        {
            // Пример 3: Матрица без строгого диагонального преобладания (медленная сходимость)
            matrixTextBox.Text = "2 1 1\r\n1 2 1\r\n1 1 2";
            vectorTextBox.Text = "4 4 4";
            initialGuessTextBox.Text = "0";
            toleranceTextBox.Text = "0.0001";
            maxIterationsTextBox.Text = "100";
        }

        private double[] CreateInitialGuess(int size, double value)
        {
            double[] x0 = new double[size];
            for (int i = 0; i < size; i++)
            {
                x0[i] = value;
            }
            return x0;
        }

        private double[,] ParseMatrix(string text)
        {
            string[] lines = text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            int rows = lines.Length;
            int cols = lines[0].Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Length;

            double[,] matrix = new double[rows, cols];

            for (int i = 0; i < rows; i++)
            {
                string[] elements = lines[i].Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                for (int j = 0; j < cols; j++)
                {
                    matrix[i, j] = double.Parse(elements[j]);
                }
            }

            return matrix;
        }

        private double[] ParseVector(string text)
        {
            string[] elements = text.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            double[] vector = new double[elements.Length];

            for (int i = 0; i < elements.Length; i++)
            {
                vector[i] = double.Parse(elements[i]);
            }

            return vector;
        }

        private (double[] solution, List<double> residuals, int iterations) SolveJacobi(double[,] A, double[] b, double[] x0, double tolerance, int maxIterations)
        {
            int n = b.Length;
            double[] x = new double[n];
            double[] xNew = new double[n];
            Array.Copy(x0, x, n);

            List<double> residuals = new List<double>();

            for (int k = 0; k < maxIterations; k++)
            {
                for (int i = 0; i < n; i++)
                {
                    double sum = 0;
                    for (int j = 0; j < n; j++)
                    {
                        if (i != j)
                        {
                            sum += A[i, j] * x[j];
                        }
                    }
                    xNew[i] = (b[i] - sum) / A[i, i];
                }

                double residual = CalculateResidual(A, b, xNew);
                residuals.Add(residual);

                // Проверка сходимости
                if (residual < tolerance)
                {
                    return (xNew, residuals, k + 1);
                }

                Array.Copy(xNew, x, n);
            }

            return (xNew, residuals, maxIterations);
        }

        private (double[] solution, List<double> residuals, int iterations) SolveSeidel(double[,] A, double[] b, double[] x0, double tolerance, int maxIterations)
        {
            int n = b.Length;
            double[] x = new double[n];
            Array.Copy(x0, x, n);

            List<double> residuals = new List<double>();

            for (int k = 0; k < maxIterations; k++)
            {
                for (int i = 0; i < n; i++)
                {
                    double sum = 0;
                    for (int j = 0; j < n; j++)
                    {
                        if (i != j)
                        {
                            sum += A[i, j] * x[j];
                        }
                    }
                    x[i] = (b[i] - sum) / A[i, i];
                }

                double residual = CalculateResidual(A, b, x);
                residuals.Add(residual);

                // Проверка сходимости
                if (residual < tolerance)
                {
                    return (x, residuals, k + 1);
                }
            }

            return (x, residuals, maxIterations);
        }

        private double CalculateResidual(double[,] A, double[] b, double[] x)
        {
            int n = b.Length;
            double residual = 0;

            for (int i = 0; i < n; i++)
            {
                double sum = 0;
                for (int j = 0; j < n; j++)
                {
                    sum += A[i, j] * x[j];
                }
                residual += Math.Pow(b[i] - sum, 2);
            }

            return Math.Sqrt(residual);
        }

        private void DisplayResults((double[] solution, List<double> residuals, int iterations) jacobi,
                                  (double[] solution, List<double> residuals, int iterations) seidel)
        {
            resultTextBox.Clear();

            resultTextBox.AppendText("=== МЕТОД ЯКОБИ ===\n");
            resultTextBox.AppendText($"Итераций: {jacobi.iterations}\n");
            resultTextBox.AppendText($"Финальная невязка: {jacobi.residuals[jacobi.residuals.Count - 1]:E6}\n");
            resultTextBox.AppendText("Решение: ");
            foreach (var val in jacobi.solution)
            {
                resultTextBox.AppendText($"{val:F6} ");
            }
            resultTextBox.AppendText("\n\n");

            resultTextBox.AppendText("=== МЕТОД ЗЕЙДЕЛЯ ===\n");
            resultTextBox.AppendText($"Итераций: {seidel.iterations}\n");
            resultTextBox.AppendText($"Финальная невязка: {seidel.residuals[seidel.residuals.Count - 1]:E6}\n");
            resultTextBox.AppendText("Решение: ");
            foreach (var val in seidel.solution)
            {
                resultTextBox.AppendText($"{val:F6} ");
            }
            resultTextBox.AppendText("\n");
        }

        private void PlotResiduals((double[] solution, List<double> residuals, int iterations) jacobi,
                                 (double[] solution, List<double> residuals, int iterations) seidel)
        {
            GraphPane pane = zedGraphControl.GraphPane;
            pane.CurveList.Clear();
            pane.Title.Text = "Зависимость нормы невязки от номера итерации";
            pane.XAxis.Title.Text = "Номер итерации";
            pane.YAxis.Title.Text = "Норма невязки";

            // Данные для метода Якоби (только до реального количества итераций)
            double[] xJacobi = new double[jacobi.iterations];
            double[] yJacobi = new double[jacobi.iterations];
            for (int i = 0; i < jacobi.iterations; i++)
            {
                xJacobi[i] = i + 1;
                yJacobi[i] = jacobi.residuals[i];
            }

            // Данные для метода Зейделя (только до реального количества итераций)
            double[] xSeidel = new double[seidel.iterations];
            double[] ySeidel = new double[seidel.iterations];
            for (int i = 0; i < seidel.iterations; i++)
            {
                xSeidel[i] = i + 1;
                ySeidel[i] = seidel.residuals[i];
            }

            LineItem jacobiCurve = pane.AddCurve("Метод Якоби", xJacobi, yJacobi, Color.Blue, SymbolType.None);
            LineItem seidelCurve = pane.AddCurve("Метод Зейделя", xSeidel, ySeidel, Color.Red, SymbolType.None);

            pane.YAxis.Type = AxisType.Log;
            zedGraphControl.AxisChange();
            zedGraphControl.Invalidate();
        }
    }
}