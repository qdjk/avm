﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AVM8_5
{
    internal class Program
    {
        
        static void FFT(double[] re, double[] im, bool inv)
        {
            int n = re.Length;

            
            for (int i = 1, j = 0; i < n; i++)
            {
                int bit = n >> 1;
                for (; (j & bit) != 0; bit >>= 1) j ^= bit;
                j ^= bit;
                if (i < j)
                {
                    (re[i], re[j]) = (re[j], re[i]);
                    (im[i], im[j]) = (im[j], im[i]);
                }
            }

            for (int len = 2; len <= n; len <<= 1)
            {
                double ang = 2 * Math.PI / len * (inv ? -1 : 1);
                double wlenRe = Math.Cos(ang), wlenIm = Math.Sin(ang);

                for (int i = 0; i < n; i += len)
                {
                    double wRe = 1, wIm = 0;
                    int half = len >> 1;

                    for (int j = 0; j < half; j++)
                    {
                        int u = i + j, v = u + half;

                        double tRe = re[v] * wRe - im[v] * wIm;
                        double tIm = re[v] * wIm + im[v] * wRe;

                        double uRe = re[u], uIm = im[u];
                        re[u] = uRe + tRe; im[u] = uIm + tIm;
                        re[v] = uRe - tRe; im[v] = uIm - tIm;

                        double nwRe = wRe * wlenRe - wIm * wlenIm;
                        double nwIm = wRe * wlenIm + wIm * wlenRe;
                        wRe = nwRe; wIm = nwIm;
                    }
                }
            }

            if (inv)
            {
                for (int i = 0; i < n; i++) { re[i] /= n; im[i] /= n; }
            }
        }
      
        static int NextPow2(int x)
        {
            int p = 1; while (p < x) p <<= 1; return p;
        }

        
        static long[] Mul(double[] a, double[] b)
        {
            int need = a.Length + b.Length - 1;
            int n = NextPow2(need);

            double[] ar = new double[n], ai = new double[n];
            double[] br = new double[n], bi = new double[n];

            for (int i = 0; i < a.Length; i++) ar[i] = a[i];
            for (int i = 0; i < b.Length; i++) br[i] = b[i];

            FFT(ar, ai, false);
            FFT(br, bi, false);

            for (int i = 0; i < n; i++)
            {
                double rr = ar[i] * br[i] - ai[i] * bi[i];
                double ii = ar[i] * bi[i] + ai[i] * br[i];
                ar[i] = rr; ai[i] = ii;
            }

            FFT(ar, ai, true); 

            long[] c = new long[need];
            for (int i = 0; i < need; i++) c[i] = (long)Math.Round(ar[i]);
            return c;
        }
        

        static void Main()
        {
            
            double[] a = { 0, 1, 1 };
            
            double[] b = { 0, 1, 0, 1 };

            long[] c = Mul(a, b);

            Console.WriteLine("Кф: C(x) = (x + x^2)(x + x^3):");
            for (int k = 0; k < c.Length; k++)
                Console.WriteLine($"c[{k}] = {c[k]}");

            
        }
    }
}

