﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp13
{
    internal class Program
    {
        
        static double F(double x)
        {
            return x * x + 5;
        }

        static void Main()
        {
           
            double a = 1.0;
            double b = 2.0;
            double eps = 1e-6;
            int maxIter = 100;

            Console.WriteLine("F(x) = x^2 + 5");
            Console.WriteLine($"Интервал: [{a}; {b}], eps={eps}, maxIter={maxIter}");
            Console.WriteLine();

            Bisection(a, b, eps, maxIter);
            Console.WriteLine();
            Secant(a, b, eps, maxIter);

            Console.ReadLine();
        }

        static void Bisection(double a, double b, double eps, int maxIter)
        {
            double fa = F(a);
            double fb = F(b);

            Console.WriteLine("Метод деления отрезка пополам (биссекция)");

            if (fa == 0) { PrintResult(a, 0, fa); return; }
            if (fb == 0) { PrintResult(b, 0, fb); return; }

            if (fa * fb > 0)
            {
                Console.WriteLine("Ошибка: F(a) и F(b) одного знака. Для биссекции нужно F(a)*F(b) < 0.");
                Console.WriteLine($"F(a)={fa}, F(b)={fb}");
                return;
            }

            double left = a, right = b;
            double mid = 0, fmid = 0;

            int iter = 0;
            while (iter < maxIter)
            {
                mid = (left + right) / 2.0;
                fmid = F(mid);

                if (Math.Abs(fmid) < eps) break;
                if ((right - left) / 2.0 < eps) break;

               
                if (F(left) * fmid < 0)
                    right = mid;
                else
                    left = mid;

                iter++;
            }

            PrintResult(mid, iter, fmid);
        }

        static void Secant(double a, double b, double eps, int maxIter)
        {
            Console.WriteLine("Метод секущих: ");

            double x0 = a;
            double x1 = b;
            double f0 = F(x0);
            double f1 = F(x1);

            int iter = 0;
            while (iter < maxIter)
            {
                double denom = (f1 - f0);
                if (Math.Abs(denom) < 1e-15)
                {
                    Console.WriteLine("Ошибка: (f1 - f0) почти 0, делить нельзя. Остановка.");
                    Console.WriteLine($"x0={x0}, x1={x1}, f0={f0}, f1={f1}");
                    return;
                }

                double x2 = x1 - f1 * (x1 - x0) / denom;
                double f2 = F(x2);

                if (Math.Abs(f2) < eps || Math.Abs(x2 - x1) < eps)
                {
                    PrintResult(x2, iter + 1, f2);
                    return;
                }

                x0 = x1; f0 = f1;
                x1 = x2; f1 = f2;

                iter++;
            }

            PrintResult(x1, iter, f1);
        }

        static void PrintResult(double x, int iters, double fx)
        {
            Console.WriteLine("x = " + x);
            Console.WriteLine("F(x) = " + fx);
            Console.WriteLine("Итерации: " + iters);
        }
    }
}
