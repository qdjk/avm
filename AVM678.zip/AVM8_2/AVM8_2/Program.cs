﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AVM8_2
{
    internal class Program
    {
        static void Main()
        {

            int n = int.Parse(Console.ReadLine() ?? "0");

            double[,] a = new double[n, n];

            for (int i = 0; i < n; i++)
            {
                string line = Console.ReadLine() ?? "";
                string[] parts = line.Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

                for (int j = 0; j < n; j++)
                    a[i, j] = ParseDouble(parts[j]);
            }


            double[,] inverse = InverseByGaussJordan(a);

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (j > 0) Console.Write(" ");
                    Console.Write(inverse[i, j].ToString("F6", CultureInfo.InvariantCulture));
                }
                Console.WriteLine();
            }
        }


        static double ParseDouble(string s)
        {
            s = s.Replace(',', '.');
            return double.Parse(s, CultureInfo.InvariantCulture);
        }


        static double[,] InverseByGaussJordan(double[,] input)
        {
            int n = input.GetLength(0);


            double[,] augmented = new double[n, 2 * n];


            for (int i = 0; i < n; i++)
            {

                for (int j = 0; j < n; j++)
                    augmented[i, j] = input[i, j];


                for (int j = 0; j < n; j++)
                    augmented[i, n + j] = (i == j) ? 1.0 : 0.0;
            }

            const double eps = 1e-12;


            for (int col = 0; col < n; col++)
            {

                int pivotRow = col;
                double best = Math.Abs(augmented[col, col]);

                for (int r = col + 1; r < n; r++)
                {
                    double v = Math.Abs(augmented[r, col]);
                    if (v > best)
                    {
                        best = v;
                        pivotRow = r;
                    }
                }


                if (best < eps)
                    throw new InvalidOperationException("Матрица вырождена (обратной не существует).");


                if (pivotRow != col)
                {
                    for (int j = 0; j < 2 * n; j++)
                    {
                        double temp = augmented[col, j];
                        augmented[col, j] = augmented[pivotRow, j];
                        augmented[pivotRow, j] = temp;
                    }
                }


                double pivot = augmented[col, col];
                for (int j = 0; j < 2 * n; j++)
                    augmented[col, j] /= pivot;

                for (int r = 0; r < n; r++)
                {
                    if (r == col) continue;

                    double factor = augmented[r, col];
                    if (Math.Abs(factor) < eps) continue;

                    for (int j = 0; j < 2 * n; j++)
                        augmented[r, j] -= factor * augmented[col, j];
                }
            }

            double[,] inverse = new double[n, n];
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                    inverse[i, j] = augmented[i, n + j];

            return inverse;
        }
    }
}
