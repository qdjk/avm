﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Globalization;
using ZedGraph;
namespace AVM6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBoxMethod.SelectedIndex = 0;
            SetupGraph();
        }

        // y' = y
        private double F(double x, double y)
        {
            return y;
        }

        // Точное решение
        private double Exact(double x)
        {
            return Math.Exp(x);
        }

        private void SetupGraph()
        {
            GraphPane pane = zedGraphControl1.GraphPane;
            pane.Title.Text = "Задача Коши: y' = y, y(0)=1";
            pane.XAxis.Title.Text = "x";
            pane.YAxis.Title.Text = "y(x)";
            pane.CurveList.Clear();
            zedGraphControl1.AxisChange();
            zedGraphControl1.Invalidate();
        }

        private void buttonSolve_Click(object sender, EventArgs e)
        {
            double h;

            if (!double.TryParse(
                    textBoxH.Text.Replace(',', '.'),
                    NumberStyles.Any,
                    CultureInfo.InvariantCulture,
                    out h))
            {
                MessageBox.Show("Неверное значение шага h");
                return;
            }

            if (h <= 0 || h > 1)
            {
                MessageBox.Show("h должно быть в (0, 1]");
                return;
            }

            int method = comboBoxMethod.SelectedIndex; 

            GraphPane pane = zedGraphControl1.GraphPane;
            pane.CurveList.Clear();

            PointPairList exactPoints = new PointPairList();
            PointPairList numPoints = new PointPairList();

            double x = 0.0;
            double y = 1.0; 

            exactPoints.Add(x, Exact(x));
            numPoints.Add(x, y);

            while (x < 1.0 - 1e-12)
            {
                double step = h;
                if (x + step > 1.0)
                    step = 1.0 - x;

                if (method == 0)
                {
                    // Метод Эйлера
                    y = y + step * F(x, y);
                }
                else
                {
                    // Метод Рунге–Кутта 2-го порядка
                    double k1 = F(x, y);
                    double k2 = F(x + step / 2.0, y + step * k1 / 2.0);
                    y = y + step * k2;
                }

                x += step;

                exactPoints.Add(x, Exact(x));
                numPoints.Add(x, y);
            }

            // Количество шагов
            int steps = numPoints.Count - 1;
            textBoxSteps.Text = steps.ToString();

            pane.AddCurve("Точное решение", exactPoints, System.Drawing.Color.Blue, SymbolType.None);
            pane.AddCurve("Численное решение", numPoints, System.Drawing.Color.Red, SymbolType.None);

            zedGraphControl1.AxisChange();
            zedGraphControl1.Invalidate();
        }
    }
}
