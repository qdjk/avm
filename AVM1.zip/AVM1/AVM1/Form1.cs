﻿using System;
using System.Drawing;
using System.Windows.Forms;
using ZedGraph;
using System.Collections.Generic;

namespace InterpolationApp
{
    public partial class Form1 : Form
    {
        private ZedGraphControl zedGraphControl;
        private ComboBox functionComboBox;
        private ComboBox interpolationTypeComboBox;
        private NumericUpDown nValueNumeric;
        private Button calculateButton;
        private CheckBox showOriginalCheckBox;
        private CheckBox showLagrangeCheckBox;
        private CheckBox showSplineCheckBox;

        public Form1()
        {
            InitializeComponent();
            SetupZedGraph();
        }

        private void InitializeComponent()
        {
            this.Size = new Size(1200, 800);
            this.Text = "Интерполяция функций";

            // Создание элементов управления
            zedGraphControl = new ZedGraphControl
            {
                Location = new Point(200, 10),
                Size = new Size(900, 700),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };

            functionComboBox = new ComboBox
            {
                Location = new Point(10, 10),
                Size = new Size(180, 25),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            functionComboBox.Items.AddRange(new string[] {
                "f(x) = x² (малая производная)",
                "f(x) = |x|"
            });
            functionComboBox.SelectedIndex = 0;

            interpolationTypeComboBox = new ComboBox
            {
                Location = new Point(10, 45),
                Size = new Size(180, 25),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            interpolationTypeComboBox.Items.AddRange(new string[] {
                "Полином Лагранжа (равноотстоящие)",
                "Полином Лагранжа (Чебышёв)",
                "Кубический сплайн"
            });
            interpolationTypeComboBox.SelectedIndex = 0;

            nValueNumeric = new NumericUpDown
            {
                Location = new Point(10, 80),
                Size = new Size(180, 25),
                Minimum = 3,
                Maximum = 50,
                Value = 5
            };

            showOriginalCheckBox = new CheckBox
            {
                Location = new Point(10, 115),
                Size = new Size(180, 25),
                Text = "Показать исходную функцию",
                Checked = true
            };

            showLagrangeCheckBox = new CheckBox
            {
                Location = new Point(10, 140),
                Size = new Size(180, 25),
                Text = "Показать интерполяцию",
                Checked = true
            };

            showSplineCheckBox = new CheckBox
            {
                Location = new Point(10, 165),
                Size = new Size(180, 25),
                Text = "Показать сплайн",
                Checked = true
            };

            calculateButton = new Button
            {
                Location = new Point(10, 200),
                Size = new Size(180, 35),
                Text = "Построить графики"
            };
            calculateButton.Click += CalculateButton_Click;

            // Добавление элементов на форму
            this.Controls.Add(zedGraphControl);
            this.Controls.Add(functionComboBox);
            this.Controls.Add(interpolationTypeComboBox);
            this.Controls.Add(nValueNumeric);
            this.Controls.Add(showOriginalCheckBox);
            this.Controls.Add(showLagrangeCheckBox);
            this.Controls.Add(showSplineCheckBox);
            this.Controls.Add(calculateButton);
        }

        private void SetupZedGraph()
        {
            GraphPane pane = zedGraphControl.GraphPane;
            pane.Title.Text = "Интерполяция функций";
            pane.XAxis.Title.Text = "x";
            pane.YAxis.Title.Text = "f(x)";
            pane.XAxis.Scale.Min = -1;
            pane.XAxis.Scale.Max = 1;
            pane.YAxis.Scale.Min = -0.2;
            pane.YAxis.Scale.Max = 1.2;
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            DrawGraphs();
        }

        private void DrawGraphs()
        {
            GraphPane pane = zedGraphControl.GraphPane;
            pane.CurveList.Clear();

            int n = (int)nValueNumeric.Value;
            double[] xValues = GenerateXValues(1000);
            int functionIndex = functionComboBox.SelectedIndex;
            int interpolationType = interpolationTypeComboBox.SelectedIndex;

            // Исходная функция
            if (showOriginalCheckBox.Checked)
            {
                double[] yOriginal = CalculateFunction(xValues, functionIndex);
                PointPairList originalPoints = new PointPairList();
                for (int i = 0; i < xValues.Length; i++)
                {
                    originalPoints.Add(xValues[i], yOriginal[i]);
                }
                LineItem originalCurve = pane.AddCurve("Исходная функция", originalPoints, Color.Black, SymbolType.None);
                originalCurve.Line.Width = 2f;
            }

            // Интерполяция
            if (showLagrangeCheckBox.Checked && interpolationType != 2)
            {
                double[] nodesX, nodesY;

                if (interpolationType == 0) // Равноотстоящие узлы
                {
                    nodesX = GenerateEquidistantNodes(n);
                }
                else // Чебышёвские узлы
                {
                    nodesX = GenerateChebyshevNodes(n);
                }

                nodesY = CalculateFunction(nodesX, functionIndex);

                double[] yInterpolated = new double[xValues.Length];
                for (int i = 0; i < xValues.Length; i++)
                {
                    yInterpolated[i] = LagrangeInterpolation(nodesX, nodesY, xValues[i]);
                }

                PointPairList interpolatedPoints = new PointPairList();
                for (int i = 0; i < xValues.Length; i++)
                {
                    interpolatedPoints.Add(xValues[i], yInterpolated[i]);
                }

                string methodName = interpolationType == 0 ? "Лагранж (равноот.)" : "Лагранж (Чебышёв)";
                LineItem interpolatedCurve = pane.AddCurve(methodName, interpolatedPoints, Color.Red, SymbolType.None);
                interpolatedCurve.Line.Width = 1.5f;

                // Отображение узлов интерполяции
                PointPairList nodePoints = new PointPairList();
                for (int i = 0; i < nodesX.Length; i++)
                {
                    nodePoints.Add(nodesX[i], nodesY[i]);
                }
                pane.AddCurve("Узлы", nodePoints, Color.Blue, SymbolType.Circle);
            }

            // Кубический сплайн
            if (showSplineCheckBox.Checked && (interpolationType == 2 || interpolationTypeComboBox.SelectedIndex == 2))
            {
                double[] nodesX = GenerateEquidistantNodes(n);
                double[] nodesY = CalculateFunction(nodesX, functionIndex);

                double[] ySpline = CalculateCubicSpline(nodesX, nodesY, xValues);

                PointPairList splinePoints = new PointPairList();
                for (int i = 0; i < xValues.Length; i++)
                {
                    splinePoints.Add(xValues[i], ySpline[i]);
                }

                LineItem splineCurve = pane.AddCurve("Кубический сплайн", splinePoints, Color.Green, SymbolType.None);
                splineCurve.Line.Width = 1.5f;

                // Отображение узлов сплайна
                PointPairList nodePoints = new PointPairList();
                for (int i = 0; i < nodesX.Length; i++)
                {
                    nodePoints.Add(nodesX[i], nodesY[i]);
                }
                pane.AddCurve("Узлы сплайна", nodePoints, Color.Orange, SymbolType.Square);
            }

            zedGraphControl.AxisChange();
            zedGraphControl.Invalidate();
        }

        private double[] GenerateXValues(int count)
        {
            double[] xValues = new double[count];
            double step = 2.0 / (count - 1);
            for (int i = 0; i < count; i++)
            {
                xValues[i] = -1 + i * step;
            }
            return xValues;
        }

        private double[] GenerateEquidistantNodes(int n)
        {
            double[] nodes = new double[n];
            double step = 2.0 / (n - 1);
            for (int i = 0; i < n; i++)
            {
                nodes[i] = -1 + i * step;
            }
            return nodes;
        }

        private double[] GenerateChebyshevNodes(int n)
        {
            double[] nodes = new double[n];
            for (int i = 0; i < n; i++)
            {
                nodes[i] = Math.Cos(Math.PI * (2 * i + 1) / (2 * n));
            }
            Array.Sort(nodes);
            return nodes;
        }

        private double[] CalculateFunction(double[] x, int functionIndex)
        {
            double[] y = new double[x.Length];
            for (int i = 0; i < x.Length; i++)
            {
                switch (functionIndex)
                {
                    case 0: // x²
                        y[i] = x[i] * x[i];
                        break;
                    case 2: // |x|
                        y[i] = Math.Abs(x[i]);
                        break;
                }
            }
            return y;
        }

        private double LagrangeInterpolation(double[] xNodes, double[] yNodes, double x)
        {
            double result = 0;
            int n = xNodes.Length;

            for (int i = 0; i < n; i++)
            {
                double term = yNodes[i];
                for (int j = 0; j < n; j++)
                {
                    if (j != i)
                    {
                        term *= (x - xNodes[j]) / (xNodes[i] - xNodes[j]);
                    }
                }
                result += term;
            }
            return result;
        }

        private double[] CalculateCubicSpline(double[] xNodes, double[] yNodes, double[] xValues)
        {
            int n = xNodes.Length;
            double[] h = new double[n - 1];
            double[] alpha = new double[n - 1];
            double[] l = new double[n];
            double[] mu = new double[n];
            double[] z = new double[n];
            double[] c = new double[n];
            double[] b = new double[n - 1];
            double[] d = new double[n - 1];

            // Вычисление разностей
            for (int i = 0; i < n - 1; i++)
            {
                h[i] = xNodes[i + 1] - xNodes[i];
            }

            // Вычисление alpha
            for (int i = 1; i < n - 1; i++)
            {
                alpha[i] = (3 / h[i]) * (yNodes[i + 1] - yNodes[i]) - (3 / h[i - 1]) * (yNodes[i] - yNodes[i - 1]);
            }

            // Прямой ход метода прогонки
            l[0] = 1;
            mu[0] = 0;
            z[0] = 0;

            for (int i = 1; i < n - 1; i++)
            {
                l[i] = 2 * (xNodes[i + 1] - xNodes[i - 1]) - h[i - 1] * mu[i - 1];
                mu[i] = h[i] / l[i];
                z[i] = (alpha[i] - h[i - 1] * z[i - 1]) / l[i];
            }

            l[n - 1] = 1;
            z[n - 1] = 0;
            c[n - 1] = 0;

            // Обратный ход
            for (int j = n - 2; j >= 0; j--)
            {
                c[j] = z[j] - mu[j] * c[j + 1];
                b[j] = (yNodes[j + 1] - yNodes[j]) / h[j] - h[j] * (c[j + 1] + 2 * c[j]) / 3;
                d[j] = (c[j + 1] - c[j]) / (3 * h[j]);
            }

            // Вычисление значений сплайна в точках xValues
            double[] ySpline = new double[xValues.Length];
            for (int i = 0; i < xValues.Length; i++)
            {
                double x = xValues[i];
                int segment = FindSegment(xNodes, x);

                if (segment >= 0 && segment < n - 1)
                {
                    double dx = x - xNodes[segment];
                    ySpline[i] = yNodes[segment] + b[segment] * dx + c[segment] * dx * dx + d[segment] * dx * dx * dx;
                }
                else
                {
                    ySpline[i] = double.NaN;
                }
            }

            return ySpline;
        }

        private int FindSegment(double[] xNodes, double x)
        {
            for (int i = 0; i < xNodes.Length - 1; i++)
            {
                if (x >= xNodes[i] && x <= xNodes[i + 1])
                {
                    return i;
                }
            }
            return -1;
        }
    }
}