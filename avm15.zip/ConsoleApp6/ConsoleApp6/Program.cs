﻿using System;

namespace EigenSimple
{
    class Program
    {
        static void Main()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.Write("Введите размер матрицы n: ");
            int n = int.Parse(Console.ReadLine());

            double[,] A = new double[n, n];

            Console.WriteLine("Введите матрицу A построчно, элементы через пробел:");
            for (int i = 0; i < n; i++)
            {
                string line = Console.ReadLine();
                string[] parts = line.Split(' ');

                if (parts.Length != n)
                {
                    Console.WriteLine("Ошибка: в строке должно быть " + n + " чисел.");
                    return;
                }

                for (int j = 0; j < n; j++)
                {
                    string s = parts[j];
                    A[i, j] = double.Parse(s);
                }
            }

            Console.Write("Введите точность: ");
            string epsStr = Console.ReadLine();
            double eps = double.Parse(epsStr);

            Console.WriteLine();
            Console.WriteLine("Метод прямой итерации (степенной)");
            PowerIteration(A, eps);

            Console.WriteLine();
            Console.WriteLine("Метод вращений Якоби (для симметричной матрицы)");
            Jacobi(A, eps);

            Console.WriteLine();
            Console.ReadLine();
        }

        static void PowerIteration(double[,] A, double eps)
        {
            int n = A.GetLength(0);

            double[] x = new double[n];
            for (int i = 0; i < n; i++)
                x[i] = 1.0;

            Normalize(x);

            double lambdaPrev = 0.0;
            double lambda = 0.0;
            int iterations = 0;
            int maxIter = 10000;

            while (iterations < maxIter)
            {
                iterations++;

                // y = A * x
                double[] y = Multiply(A, x);

                // λ = (x, Ax) / (x, x)
                lambda = Dot(x, y) / Dot(x, x);

                // нормировка
                Normalize(y);
                x = y;

                if (Math.Abs(lambda - lambdaPrev) < eps)
                    break;

                lambdaPrev = lambda;
            }

            Console.WriteLine("Собственное число λ: " + lambda);
            Console.WriteLine("Количество итераций: " + iterations);
            Console.WriteLine("Собственный вектор (нормированный):");
            for (int i = 0; i < n; i++)
                Console.WriteLine("x[" + i + "] = " + x[i]);
        }

        static void Jacobi(double[,] A, double eps)
        {
            int n = A.GetLength(0);
            double[,] a = (double[,])A.Clone();

            double[,] V = new double[n, n];
            for (int i = 0; i < n; i++)
                V[i, i] = 1.0;

            int iterations = 0;
            int maxIter = 100000;

            while (true)
            {
                iterations++;
                if (iterations > maxIter)
                    break;

                // ищем максимальный по модулю вне диагональный элемент
                int p = 0;
                int q = 1;
                double max = 0.0;

                for (int i = 0; i < n; i++)
                {
                    for (int j = i + 1; j < n; j++)
                    {
                        double val = Math.Abs(a[i, j]);
                        if (val > max)
                        {
                            max = val;
                            p = i;
                            q = j;
                        }
                    }
                }

                //остановка
                if (max < eps)
                    break;

                double app = a[p, p];
                double aqq = a[q, q];
                double apq = a[p, q];

                // угол поворота
                double phi = 0.5 * Math.Atan2(2.0 * apq, app - aqq);
                double c = Math.Cos(phi);
                double s = Math.Sin(phi);

                // обновляем строки/столбцы p и q
                for (int i = 0; i < n; i++)
                {
                    if (i == p || i == q)
                        continue;

                    double aip = a[i, p];
                    double aiq = a[i, q];

                    double aipNew = c * aip - s * aiq;
                    double aiqNew = s * aip + c * aiq;

                    a[i, p] = aipNew;
                    a[p, i] = aipNew;

                    a[i, q] = aiqNew;
                    a[q, i] = aiqNew;
                }

                // диагональ
                double appNew = c * c * app - 2.0 * s * c * apq + s * s * aqq;
                double aqqNew = s * s * app + 2.0 * s * c * apq + c * c * aqq;

                a[p, p] = appNew;
                a[q, q] = aqqNew;
                a[p, q] = 0.0;
                a[q, p] = 0.0;

                // обновляем матрицу собственных векторов V
                for (int i = 0; i < n; i++)
                {
                    double vip = V[i, p];
                    double viq = V[i, q];

                    V[i, p] = c * vip - s * viq;
                    V[i, q] = s * vip + c * viq;
                }
            }

            Console.WriteLine("Собственные значения (по диагонали матрицы после диагонализации):");
            for (int i = 0; i < n; i++)
                Console.WriteLine("λ[" + i + "] = " + a[i, i]);

            Console.WriteLine("Количество итераций: " + iterations);
        }


        static double[] Multiply(double[,] A, double[] x)
        {
            int n = A.GetLength(0);
            int m = A.GetLength(1);

            double[] y = new double[n];

            for (int i = 0; i < n; i++)
            {
                double sum = 0.0;
                for (int j = 0; j < m; j++)
                    sum += A[i, j] * x[j];
                y[i] = sum;
            }

            return y;
        }

        static double Dot(double[] a, double[] b)
        {
            double s = 0.0;
            for (int i = 0; i < a.Length; i++)
                s += a[i] * b[i];
            return s;
        }

        static void Normalize(double[] x)
        {
            double normSq = Dot(x, x);
            if (normSq == 0.0)
                throw new Exception("Нулевой вектор, нормировать нельзя");

            double norm = Math.Sqrt(normSq);
            for (int i = 0; i < x.Length; i++)
                x[i] = x[i] / norm;
        }
    }
}
