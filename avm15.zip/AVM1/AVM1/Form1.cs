using System;
using System.Windows.Forms;
using ZedGraph;

namespace AVM1
{
    public partial class Form1 : Form
    {
        // Коэффициенты сплайна
        private double[] splineX;
        private double[] splineA;
        private double[] splineB;
        private double[] splineC;
        private double[] splineD;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBoxFunction.SelectedIndex = 0;
            comboBoxMethod.SelectedIndex = 0;
            SetupGraph();
        }

        private void SetupGraph()
        {
            GraphPane pane = zedGraphControl.GraphPane;
            pane.Title.Text = "Аппроксимация функций";
            pane.XAxis.Title.Text = "x";
            pane.YAxis.Title.Text = "f(x)";
            pane.CurveList.Clear();
            zedGraphControl.AxisChange();
            zedGraphControl.Invalidate();
        }

        private void buttonCalculate_Click(object sender, EventArgs e)
        {
            CalculateAndPlot();
        }

        private void CalculateAndPlot()
        {
            int n = (int)numericUpDownNodes.Value;
            double a = -1.0, b = 1.0;

            // Выбранная функция
            Func<double, double> originalFunction = GetSelectedFunction();

            // Узлы интерполяции
            double[] xNodes, yNodes;
            if (comboBoxMethod.SelectedIndex == 1) // Чебышевские узлы
            {
                xNodes = ChebyshevNodes(n, a, b);
            }
            else // Равноотстоящие узлы
            {
                xNodes = EquidistantNodes(n, a, b);
            }

            yNodes = new double[n];
            for (int i = 0; i < n; i++)
            {
                yNodes[i] = originalFunction(xNodes[i]);
            }

            GraphPane pane = zedGraphControl.GraphPane;
            pane.CurveList.Clear();

            // Оригинальная функция
            if (checkBoxShowOriginal.Checked)
            {
                PointPairList originalPoints = new PointPairList();
                int pointsCount = 1000;
                for (int i = 0; i <= pointsCount; i++)
                {
                    double x = a + (b - a) * i / pointsCount;
                    double y = originalFunction(x);
                    originalPoints.Add(x, y);
                }

                LineItem originalCurve = pane.AddCurve(
                    "Оригинальная функция",
                    originalPoints,
                    System.Drawing.Color.Blue,
                    SymbolType.None
                );
                originalCurve.Line.Width = 2f;
            }

            // Аппроксимация (Лагранж или кубический сплайн)
            if (checkBoxShowInterpolation.Checked)
            {
                PointPairList approxPoints = new PointPairList();
                int pointsCount = 1000;

                bool useSpline = (comboBoxMethod.SelectedIndex == 2);
                if (useSpline)
                {
                    // Считаем коэффициенты кубического сплайна по узлам
                    CalculateSplineCoefficients(xNodes, yNodes);
                }

                for (int i = 0; i <= pointsCount; i++)
                {
                    double x = a + (b - a) * i / pointsCount;
                    double y;

                    if (useSpline)
                    {
                        y = EvaluateSpline(x);
                    }
                    else
                    {
                        y = LagrangeInterpolation(x, xNodes, yNodes);
                    }

                    approxPoints.Add(x, y);
                }

                string methodName = comboBoxMethod.SelectedItem.ToString();
                LineItem approxCurve = pane.AddCurve(
                    methodName,
                    approxPoints,
                    System.Drawing.Color.Red,
                    SymbolType.None
                );
                approxCurve.Line.Width = 1.5f;
            }

            // Узлы интерполяции
            PointPairList nodesPoints = new PointPairList();
            for (int i = 0; i < n; i++)
            {
                nodesPoints.Add(xNodes[i], yNodes[i]);
            }

            LineItem nodesCurve = pane.AddCurve(
                "Узлы интерполяции",
                nodesPoints,
                System.Drawing.Color.Green,
                SymbolType.Circle
            );
            nodesCurve.Line.IsVisible = false;
            nodesCurve.Symbol.Fill = new Fill(System.Drawing.Color.Green);
            nodesCurve.Symbol.Size = 5;

            zedGraphControl.AxisChange();
            zedGraphControl.Invalidate();
        }

        // Выбор функции
        private Func<double, double> GetSelectedFunction()
        {
            switch (comboBoxFunction.SelectedIndex)
            {
                case 0: // x²
                    return x => x * x;
                case 1: // 1/(1+25x²)
                    return x => 1.0 / (1 + 25 * x * x);
                case 2: // e^(x²)
                    return x => Math.Exp(x * x);
                case 3: // |x|
                    return x => Math.Abs(x);
                default:
                    return x => x * x;
            }
        }

        // Равноотстоящие узлы на [a,b]
        private double[] EquidistantNodes(int n, double a, double b)
        {
            double[] nodes = new double[n];
            for (int i = 0; i < n; i++)
            {
                nodes[i] = a + (b - a) * i / (n - 1);
            }
            return nodes;
        }

        // Узлы Чебышёва 1-го рода на [a,b], СРАЗУ по возрастанию
        private double[] ChebyshevNodes(int n, double a, double b)
        {
            double[] nodes = new double[n];
            for (int i = 0; i < n; i++)
            {
                // Делаем индексы так, чтобы t шли от -1 к 1 (узлы по возрастанию)
                int j = n - 1 - i;
                double cheb = Math.Cos(Math.PI * (2 * j + 1) / (2 * n)); // [-1,1]
                nodes[i] = (b - a) / 2.0 * cheb + (a + b) / 2.0;
            }
            return nodes;
        }

        // Полином Лагранжа
        private double LagrangeInterpolation(double x, double[] xNodes, double[] yNodes)
        {
            double result = 0.0;
            int n = xNodes.Length;

            for (int i = 0; i < n; i++)
            {
                double term = yNodes[i];
                for (int j = 0; j < n; j++)
                {
                    if (j != i)
                    {
                        term *= (x - xNodes[j]) / (xNodes[i] - xNodes[j]);
                    }
                }
                result += term;
            }

            return result;
        }

        // Построение натурального кубического сплайна: заполняем splineX/A/B/C/D
        private void CalculateSplineCoefficients(double[] xNodes, double[] yNodes)
        {
            int n = xNodes.Length;

            splineX = new double[n];
            splineA = new double[n];
            splineB = new double[n];
            splineC = new double[n];
            splineD = new double[n];

            // Копируем узлы и значения
            for (int i = 0; i < n; i++)
            {
                splineX[i] = xNodes[i];
                splineA[i] = yNodes[i];
            }

            double[] h = new double[n - 1];
            double[] alpha = new double[n];

            for (int i = 0; i < n - 1; i++)
            {
                h[i] = splineX[i + 1] - splineX[i];
            }

            for (int i = 1; i < n - 1; i++)
            {
                double term1 = (splineA[i + 1] - splineA[i]) / h[i];
                double term2 = (splineA[i] - splineA[i - 1]) / h[i - 1];
                alpha[i] = 3.0 * (term1 - term2);
            }

            double[] l = new double[n];
            double[] mu = new double[n];
            double[] z = new double[n];

            l[0] = 1.0;
            mu[0] = 0.0;
            z[0] = 0.0;

            for (int i = 1; i < n - 1; i++)
            {
                l[i] = 2.0 * (splineX[i + 1] - splineX[i - 1]) - h[i - 1] * mu[i - 1];
                mu[i] = h[i] / l[i];
                z[i] = (alpha[i] - h[i - 1] * z[i - 1]) / l[i];
            }

            l[n - 1] = 1.0;
            z[n - 1] = 0.0;
            splineC[n - 1] = 0.0;

            for (int j = n - 2; j >= 0; j--)
            {
                splineC[j] = z[j] - mu[j] * splineC[j + 1];
                splineB[j] = (splineA[j + 1] - splineA[j]) / h[j]
                             - h[j] * (2.0 * splineC[j] + splineC[j + 1]) / 3.0;
                splineD[j] = (splineC[j + 1] - splineC[j]) / (3.0 * h[j]);
            }
        }

        // Значение кубического сплайна в точке x
        private double EvaluateSpline(double x)
        {
            int n = splineX.Length;

            if (x <= splineX[0])
                return splineA[0];

            if (x >= splineX[n - 1])
            {
                int jLast = n - 2;
                double dxLast = x - splineX[jLast];
                return splineA[jLast]
                       + splineB[jLast] * dxLast
                       + splineC[jLast] * dxLast * dxLast
                       + splineD[jLast] * dxLast * dxLast * dxLast;
            }

            int j = 0;
            for (int i = 0; i < n - 1; i++)
            {
                if (x >= splineX[i] && x <= splineX[i + 1])
                {
                    j = i;
                    break;
                }
            }

            double dx = x - splineX[j];
            double result = splineA[j]
                            + splineB[j] * dx
                            + splineC[j] * dx * dx
                            + splineD[j] * dx * dx * dx;

            return result;
        }
    }
}
